# CLI Test Scripts

Scripts for testing and generating decoders using the Carbon CLI.

## Scripts

- **generate_parse.sh** - Parses `dflow.json` IDL and generates decoder code without postgres/graphql
- **generate_generic.sh** - Generates a pump-generic decoder with generic postgres mode
- **generate_all_datasource_scaffolds.sh** - Generates decoders for all datasource types (helius-laserstream, yellowstone-grpc, rpc-block-subscribe, rpc-program-subscribe, rpc-transaction-crawler)
- **generate_multiple_decoders.sh** - Generates multiple decoders for various programs (marginfi-v2, jup, pump2, dlmm, circle, orca-whirlpool, kamino-lending, zeta, jup2, drift, mpl-token-metadata, raydium-clmm, token-2022, openbook-v2, dca, circle-message)
- **generate_pg_gq_combinations.sh** - Generates marginfi-v2 decoder with all postgres/graphql flag combinations
- **build_multiple_decoders.sh** - Runs cargo check on all generated decoder projects

## Files

- **IDL files**: `dflow.json`, `drift.json`, `token_metadata.json`, `raydium_clmm.json`, `token-2022.json`, `circle-message.json`
- **.env**: Environment configuration file used by generated decoders

## Usage

All scripts should be run from the `cli-scripts/` directory. They automatically detect the Carbon root directory and use relative paths.

