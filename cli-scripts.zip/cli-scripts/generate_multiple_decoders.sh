#!/bin/bash

# Generate all decoders script
# This script generates multiple decoders and copies .env file to each

set -e  # Exit on any error

# Set PROTOC environment variable if not already set
if [ -z "$PROTOC" ]; then
    if command -v protoc &> /dev/null; then
        export PROTOC=$(which protoc)
        echo "🔧 Setting PROTOC to: $PROTOC"
    else
        echo "❌ Error: protoc not found. Please install with: brew install protobuf"
        exit 1
    fi
fi

echo "🚀 Starting decoder generation for all programs..."

# Get the script directory for IDL and .env files (must be set before changing directories)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Get the carbon root directory (parent of this script's directory)
ROOT_DIR=$(cd "$SCRIPT_DIR/.." && pwd)

# Change to the carbon directory
cd "$ROOT_DIR"

# build the cli
cd packages/renderer && npm run build && cd ../cli && npm run build && cd ../..

# Generate marginfi-v2 decoder
echo "📦 Generating marginfi-v2 decoder..."
node packages/cli/dist/cli.js scaffold --name marginfi-v2 --out-dir test --idl MFv2hWf31Z9kbCa1snEPYctwafyhdvnV7FZnsebVacA --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

# Generate jup decoder
echo "📦 Generating jup decoder..."
node packages/cli/dist/cli.js scaffold --name jup --out-dir test --idl JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4 --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

# Generate pump2 decoder
echo "📦 Generating pump2 decoder..."
node packages/cli/dist/cli.js scaffold --name pump2 --out-dir test --idl pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

# Generate dlmm decoder
echo "📦 Generating dlmm decoder..."
node packages/cli/dist/cli.js scaffold --name dlmm --out-dir test --idl LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

# Generate circle decoder
echo "📦 Generating circle decoder..."
node packages/cli/dist/cli.js scaffold --name circle --out-dir test --idl CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

# Generate orca-whirlpool decoder
echo "📦 Generating orca-whirlpool decoder..."
node packages/cli/dist/cli.js scaffold --name orca-whirlpool --out-dir test --idl whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

# Generate kamino-lending decoder
echo "📦 Generating kamino-lending decoder..."
node packages/cli/dist/cli.js scaffold --name kamino-lending --out-dir test --idl KLend2g3cP87fffoy8q1mQqGKjrxjC8boSyAYavgmjD --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

# Generate zeta decoder
echo "📦 Generating zeta decoder..."
node packages/cli/dist/cli.js scaffold --name zeta --out-dir test --idl ZETAxsqBRek56DhiGXrn75yj2NHU3aYUnxvHXpkf3aD --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

# Generate jup2 decoder
echo "📦 Generating jup2 decoder..."
node packages/cli/dist/cli.js scaffold --name jup2 --out-dir test --idl j1o2qRpjcyUwEvwtcfhEQefh773ZgjxcVRry7LDqg5X --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

# Generate drift decoder
echo "📦 Generating drift decoder..."
node packages/cli/dist/cli.js scaffold --name drift --out-dir test --idl "$SCRIPT_DIR/drift.json" --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force --program-id dRiftyHA39MWEi3m9aunc5MzRF1JYuBsbn6VPcn33UH

# Generate MPL token metadata decoder

echo "📦 Generating MPL token metadata decoder..."
node packages/cli/dist/cli.js scaffold --name mpl-token-metadata --out-dir test --idl "$SCRIPT_DIR/token_metadata.json" --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force --program-id metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s

# Generate raydium-amm decoder
echo "📦 Generating raydium-clmm decoder..."
node packages/cli/dist/cli.js scaffold --name raydium-clmm --out-dir test --idl "$SCRIPT_DIR/raydium_clmm.json" --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force --program-id CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK

echo "📦 Generating token-2022 decoder..."
node packages/cli/dist/cli.js scaffold --name token-2022 --out-dir test --idl "$SCRIPT_DIR/token-2022.json" --idl-standard codama --data-source helius-laserstream --with-postgres true --with-graphql true --force --program-id TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb

echo "📦 Generating openbook-v2 decoder..."
node packages/cli/dist/cli.js scaffold --name openbook-v2 --out-dir test --idl opnb2LAfJYbRMAHHvqjCwQxanZn7ReEHp1k81EohpZb --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

echo "📦 Generating dca decoder..." 
node packages/cli/dist/cli.js scaffold --name dca --out-dir test --idl DCA265Vj8a9CEuX1eb1LWRnDT7uK6q1xMipnNyatn23M --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

echo "📦 Generating circle-message decoder..."
node packages/cli/dist/cli.js scaffold --name circle-message --out-dir test --idl "$SCRIPT_DIR/circle-message.json" --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

echo "📋 Copying .env file to all generated decoders..."

# Copy .env file to each decoder directory
if [ -f "$SCRIPT_DIR/.env" ]; then
    echo "📄 Copying .env to marginfi-v2..."
    cp "$SCRIPT_DIR/.env" test/marginfi-v2/
    
    echo "📄 Copying .env to jup..."
    cp "$SCRIPT_DIR/.env" test/jup/
    
    echo "📄 Copying .env to pump2..."
    cp "$SCRIPT_DIR/.env" test/pump2/
    
    echo "📄 Copying .env to dlmm..."
    cp "$SCRIPT_DIR/.env" test/dlmm/
    
    echo "📄 Copying .env to circle..."
    cp "$SCRIPT_DIR/.env" test/circle/
    
    echo "📄 Copying .env to orca-whirlpool..."
    cp "$SCRIPT_DIR/.env" test/orca-whirlpool/

    echo "📄 Copying .env to kamino-lending..."
    cp "$SCRIPT_DIR/.env" test/kamino-lending/

    echo "📄 Copying .env to zeta..."
    cp "$SCRIPT_DIR/.env" test/zeta/

    echo "📄 Copying .env to jup2..."
    cp "$SCRIPT_DIR/.env" test/jup2/

    echo "📄 Copying .env to drift..."
    cp "$SCRIPT_DIR/.env" test/drift/

    echo "📄 Copying .env to mpl-token-metadata..."
    cp "$SCRIPT_DIR/.env" test/mpl-token-metadata/

    echo "📄 Copying .env to raydium-clmm..."
    cp "$SCRIPT_DIR/.env" test/raydium-clmm/

    echo "📄 Copying .env to token-2022..." 
    cp "$SCRIPT_DIR/.env" test/token-2022/

    echo "📄 Copying .env to openbook-v2..."
    cp "$SCRIPT_DIR/.env" test/openbook-v2/

    echo "📄 Copying .env to dca..."
    cp "$SCRIPT_DIR/.env" test/dca/

    echo "📄 Copying .env to circle-message..."
    cp "$SCRIPT_DIR/.env" test/circle-message/

    
    echo "✅ All .env files copied successfully!"
else
    echo "⚠️  Warning: .env file not found in cli-scripts directory"
    echo "   Please ensure .env exists in cli-scripts/ before running this script"
fi

echo "🎉 All decoders generated and .env files copied!"
echo ""
echo "Generated decoders:"
echo "  - test/marginfi-v2/"
echo "  - test/jup/"
echo "  - test/pump2/"
echo "  - test/dlmm/"
echo "  - test/circle/"
echo "  - test/orca-whirlpool/"
echo "  - test/kamino-lending/"
echo "  - test/zeta/"
echo "  - test/jup2/"
echo "  - test/drift/"
echo "  - test/mpl-token-metadata/"
echo "  - test/raydium-amm/"
echo "  - test/raydium-clmm/"
echo "  - test/token-2022/"
echo "  - test/openbook-v2/"
echo "  - test/dca/"
echo "  - test/circle-message/"