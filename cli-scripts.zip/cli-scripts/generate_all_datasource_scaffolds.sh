#!/bin/bash

set -euo pipefail

# Usage:
#   ./generate_all_datasource_scaffolds.sh [OUT_DIR] [PROJECT_PREFIX]
# Defaults:
#   OUT_DIR=test
#   PROJECT_PREFIX=dlmm

OUT_DIR=${1:-test}
PREFIX=${2:-dlmm}

ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
CLI="$ROOT_DIR/packages/cli/dist/cli.js"

IDL_ADDR="LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo"
IDL_URL="mainnet-beta"

DATASOURCES=(
  "helius-laserstream"
  "yellowstone-grpc"
  "rpc-block-subscribe"
  "rpc-program-subscribe"
  "rpc-transaction-crawler"
)

# Provided environment values
DB_URL="postgresql://postgres:password@localhost:5432/postgres"
GEYSER_URL="https://laserstream-mainnet-ewr.helius-rpc.com"
X_TOKEN="82f362bf-f41d-44cd-ad82-d5a5d3825a40"
# For RPC_URL-based datasources use the provided HTTPS endpoint with API key
RPC_HTTP_URL="https://mainnet.helius-rpc.com/?api-key=${X_TOKEN}"
# Reasonable default for WS URL when needed
RPC_WS_URL_DEFAULT="wss://api.mainnet-beta.solana.com/"

echo "Building renderer and CLI..."
(cd "$ROOT_DIR/packages/renderer" && npm run build --silent)
(cd "$ROOT_DIR/packages/cli" && npm run build --silent)

mkdir -p "$ROOT_DIR/$OUT_DIR"

for DS in "${DATASOURCES[@]}"; do
  NAME="$PREFIX-${DS//\//-}"
  echo "\n=== Scaffolding $NAME with datasource: $DS ==="
  node "$CLI" scaffold \
    --name "$NAME" \
    --out-dir "$OUT_DIR" \
    --idl "$IDL_ADDR" \
    --idl-url "$IDL_URL" \
    --data-source "$DS" \
    --with-postgres true \
    --with-graphql true \
    --force

  IDX_DIR="$ROOT_DIR/$OUT_DIR/$NAME/indexer"
  PROJ_DIR="$ROOT_DIR/$OUT_DIR/$NAME"

  # Write .env with required variables based on datasource
  echo "Writing .env for $NAME..."
  {
    echo "DATABASE_URL=${DB_URL}"
    case "$DS" in
      "helius-laserstream")
        echo "GEYSER_URL=${GEYSER_URL}"
        echo "X_TOKEN=${X_TOKEN}"
        ;;
      "yellowstone-grpc")
        echo "GEYSER_URL=${GEYSER_URL}"
        echo "X_TOKEN=${X_TOKEN}"
        ;;
      "rpc-transaction-crawler")
        echo "RPC_URL=${RPC_HTTP_URL}"
        ;;
      "rpc-block-subscribe")
        echo "RPC_WS_URL=${RPC_WS_URL_DEFAULT}"
        ;;
      "rpc-program-subscribe")
        echo "RPC_WS_URL=${RPC_WS_URL_DEFAULT}"
        ;;
    esac
  } > "$PROJ_DIR/.env"
  if [[ ! -d "$IDX_DIR" ]]; then
    echo "Indexer directory not found for $NAME: $IDX_DIR" >&2
    exit 1
  fi
done

echo "\nRunning cargo checks for all generated indexers..."

for DS in "${DATASOURCES[@]}"; do
  NAME="$PREFIX-${DS//\//-}"
  IDX_PARENT_DIR="$ROOT_DIR/$OUT_DIR/$NAME"
  echo "Checking $NAME..."
  (cd "$IDX_PARENT_DIR" && cargo check -p "$NAME-indexer")
done

echo "\nAll datasource scaffolds generated and compiled successfully."


