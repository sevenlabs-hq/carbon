#!/bin/bash

# Generate all decoders script
# This script generates multiple decoders and copies .env file to each

set -e  # Exit on any error

# Set PROTOC environment variable if not already set
if [ -z "$PROTOC" ]; then
    if command -v protoc &> /dev/null; then
        export PROTOC=$(which protoc)
        echo "🔧 Setting PROTOC to: $PROTOC"
    else
        echo "❌ Error: protoc not found. Please install with: brew install protobuf"
        exit 1
    fi
fi

echo "🚀 Starting decoder generation for dlmm..."

# Get the script directory for .env file (must be set before changing directories)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Get the carbon root directory (parent of this script's directory)
ROOT_DIR=$(cd "$SCRIPT_DIR/.." && pwd)

# Change to the carbon directory
cd "$ROOT_DIR"

# build the cli
cd packages/renderer && npm run build && cd ../cli && npm run build && cd ../..

node packages/cli/dist/cli.js scaffold --name pump-generic --out-dir test --idl pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --postgres-mode generic --force

cp "$SCRIPT_DIR/.env" test/pump-generic/

cd test/pump-generic/ && cargo check

echo "✅ Done"