#!/bin/bash

# Generate all decoders script
# This script generates multiple decoders and copies .env file to each

set -e  # Exit on any error

# Set PROTOC environment variable if not already set
if [ -z "$PROTOC" ]; then
    if command -v protoc &> /dev/null; then
        export PROTOC=$(which protoc)
        echo "🔧 Setting PROTOC to: $PROTOC"
    else
        echo "❌ Error: protoc not found. Please install with: brew install protobuf"
        exit 1
    fi
fi

echo "🚀 Starting decoder generation for marginfi-v2 with all flag combinations..."

# Get the carbon root directory (parent of this script's directory)
ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)

# Change to the carbon directory
cd "$ROOT_DIR"

# build the cli
cd packages/renderer && npm run build && cd ../cli && npm run build && cd ../..

# 1. No postgres, no graphql
echo "📦 Generating marginfi-v2 (no postgres, no graphql)..."
node packages/cli/dist/cli.js scaffold --name marginfi-v2 --out-dir test --idl MFv2hWf31Z9kbCa1snEPYctwafyhdvnV7FZnsebVacA --idl-url mainnet-beta --data-source helius-laserstream --with-postgres false --with-graphql false --force

# 2. Postgres only, no graphql
echo "📦 Generating marginfi-v2-pg (postgres only)..."
node packages/cli/dist/cli.js scaffold --name marginfi-v2-pg --out-dir test --idl MFv2hWf31Z9kbCa1snEPYctwafyhdvnV7FZnsebVacA --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql false --force

# 3. GraphQL only, no postgres
echo "📦 Generating marginfi-v2-gq (graphql only)..."
node packages/cli/dist/cli.js scaffold --name marginfi-v2-gq --out-dir test --idl MFv2hWf31Z9kbCa1snEPYctwafyhdvnV7FZnsebVacA --idl-url mainnet-beta --data-source helius-laserstream --with-postgres false --with-graphql true --force

# 4. Both postgres and graphql
echo "📦 Generating marginfi-v2-pg-gq (postgres + graphql)..."
node packages/cli/dist/cli.js scaffold --name marginfi-v2-pg-gq --out-dir test --idl MFv2hWf31Z9kbCa1snEPYctwafyhdvnV7FZnsebVacA --idl-url mainnet-beta --data-source helius-laserstream --with-postgres true --with-graphql true --force

echo "✅ All marginfi-v2 combinations generated successfully!"

echo ""
echo "🔍 Running cargo check on all generated decoders..."
echo ""

# 1. Check marginfi-v2 (no postgres, no graphql)
echo "🔍 Checking marginfi-v2 (no postgres, no graphql)..."
cd test/marginfi-v2/decoder && cargo check && cd ../../..
echo "✅ marginfi-v2 check passed"
echo ""

# 2. Check marginfi-v2-pg (postgres only)
echo "🔍 Checking marginfi-v2-pg (postgres only)..."
cd test/marginfi-v2-pg/decoder && cargo check && cd ../../..
echo "✅ marginfi-v2-pg check passed"
echo ""

# 3. Check marginfi-v2-gq (graphql only)
echo "🔍 Checking marginfi-v2-gq (graphql only)..."
cd test/marginfi-v2-gq/decoder && cargo check && cd ../../..
echo "✅ marginfi-v2-gq check passed"
echo ""

# 4. Check marginfi-v2-pg-gq (both postgres and graphql)
echo "🔍 Checking marginfi-v2-pg-gq (postgres + graphql)..."
cd test/marginfi-v2-pg-gq/decoder && cargo check && cd ../../..
echo "✅ marginfi-v2-pg-gq check passed"
echo ""

echo "✅ All cargo checks completed successfully!"

