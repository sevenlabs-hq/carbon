#!/bin/bash

# Build all decoders script
# This script goes to each decoder project and runs cargo check

set -e  # Exit on any error

echo "🔨 Starting cargo check for all decoder projects..."

# Get the carbon root directory (parent of this script's directory)
ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)

# Change to the carbon directory
cd "$ROOT_DIR"

# List of decoder directories to check (relative to ROOT_DIR)
DECODERS=(
    "test/marginfi-v2"
    "test/zeta"
    "test/jup"
    "test/pump2"
    "test/kamino-lending"
    "test/raydium-clmm"
    "test/mpl-token-metadata"
    "test/orca-whirlpool"
    "test/dlmm"
    "test/drift"
    "test/dca"
    "test/jup2"
    "test/token-2022"
    "test/openbook-v2"
    "test/circle"
    "test/circle-message"
)

# Function to run cargo check in a directory
check_decoder() {
    local decoder_dir=$1
    local decoder_name=$(basename "$decoder_dir")
    local full_path="$ROOT_DIR/$decoder_dir"
    
    if [ -d "$full_path" ]; then
        echo "🔍 Checking $decoder_name decoder..."
        cd "$full_path"
        
        if [ -f "Cargo.toml" ]; then
            echo "   Running cargo check in $decoder_name..."
            cargo check
            echo "   ✅ $decoder_name check completed successfully!"
        else
            echo "   ⚠️  Warning: No Cargo.toml found in $decoder_name"
        fi
        
        cd "$ROOT_DIR"
        echo ""
    else
        echo "   ❌ Directory $full_path not found, skipping..."
        echo ""
    fi
}

# Check each decoder
for decoder in "${DECODERS[@]}"; do
    check_decoder "$decoder"
done

echo "🎉 All decoder checks completed!"
echo ""
echo "Checked decoders:"
for decoder in "${DECODERS[@]}"; do
    decoder_name=$(basename "$decoder")
    if [ -d "$ROOT_DIR/$decoder" ]; then
        echo "  ✅ $decoder_name"
    else
        echo "  ❌ $decoder_name (not found)"
    fi
done


